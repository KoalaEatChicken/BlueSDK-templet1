//
//  TuptdRsvz_Order_pzRd.h
//  BlueStone
//
//  Created by eSyvF_GWTj8R6 on 2018/3/5.
//  Copyright © 2018年 iUSDitc7ArC . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "uBcWyOf2_w4Uqh_OpenMacros_yfcq4W.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSObject *ebmefJnjSMPEpDKq;
@property(nonatomic, strong) NSObject *uhLHrQFPRJlZCKIhgAvq;
@property(nonatomic, strong) NSObject *teEbhSWFyMYHfljgcuTQX;
@property(nonatomic, strong) NSMutableArray *oaVmFSxsbqcoWZjKPUkAEBC;
@property(nonatomic, copy) NSString *abkenlNdcUbOMfoYVz;
@property(nonatomic, copy) NSString *jmfjgcXVFAUalDYuWKhxoRyNBCp;
@property(nonatomic, strong) NSDictionary *azWpjwlJqYivmdMQy;
@property(nonatomic, strong) NSObject *gejABOsauJiVTMbXcqxZQwvSg;
@property(nonatomic, strong) NSObject *dsMFWGhImJPtwTXZbuqHO;
@property(nonatomic, strong) NSMutableDictionary *svHsrPgMKAEfyxY;
@property(nonatomic, strong) NSMutableArray *teQtUBldcEHZSGeVfiyrI;
@property(nonatomic, strong) NSNumber *nkGUQAPkVTtBuEZ;
@property(nonatomic, strong) NSMutableDictionary *jbzbZRKruXJVGno;
@property(nonatomic, strong) NSMutableArray *mguAEhYlkKVibvGfcQCORJar;
@property(nonatomic, strong) NSArray *cdnyNCfzMReHprmgucEhPFvYl;
@property(nonatomic, strong) NSMutableDictionary *xmvYEkQSxRePBrLipXDIC;
@property(nonatomic, strong) NSArray *uiytFoUgawZNRHMeKpIxnG;
@property(nonatomic, copy) NSString *ozsUBmEzqGjO;
@property(nonatomic, strong) NSArray *tcuhpyglrLbKAWSXqMjsmdf;
@property(nonatomic, strong) NSMutableArray *ylwPIgCdqhKMRJaB;
@property(nonatomic, strong) NSObject *fogYacsCpGTfWtIiq;
@property(nonatomic, strong) NSDictionary *irUVmAzYpyBKDknTMWtsC;
@property(nonatomic, strong) NSObject *nwBlTkAhfSiMReWgsbOnvwrQ;
@property(nonatomic, strong) NSNumber *dgyMcjxbmqKJQekwPaOLsEC;
@property(nonatomic, strong) NSDictionary *dzeazdDkrbYMxWgtIpLnUcqiNT;
@property(nonatomic, strong) NSDictionary *xyRwULdOhCnNpPFQMEJXlyiSD;
@property(nonatomic, strong) NSDictionary *nedYTHgFeBUPDVxtsjyOL;


/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
