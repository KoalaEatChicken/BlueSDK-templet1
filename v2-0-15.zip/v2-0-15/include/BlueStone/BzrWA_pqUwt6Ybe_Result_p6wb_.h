//
//  BzrWA_pqUwt6Ybe_Result_p6wb_.h
//  BlueStone
//
//  Created by eSyvF_GWTj8R6 on 2018/3/5.
//  Copyright © 2018年 iUSDitc7ArC . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "uBcWyOf2_w4Uqh_OpenMacros_yfcq4W.h"

/** 通知：登出成功 */
extern NSString * _Nonnull const KKNotiLogoutSuccessNoti;

/* 悬浮球的初始位置 */
typedef NS_ENUM(NSInteger, FloatBallStyle) {
    
    FloatBallStyleDefault,
    FloatBallStyleCenterLeft,
    FloatBallStyleCenterRight,
    FloatBallStyleTopLeft,
    FloatBallStyleTopRight,
    FloatBallStyleBottomLeft,
    FloatBallStyleBottomRight,
};

/* 制服结果的状态码 */
typedef NS_ENUM(NSInteger, KKSettleBillStatus) {
    
    /** 失败  */
    KKSettleBillStatusFailure,
    
    /** 移动端内购成功的回调，但是制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusIapSuccess,
    
    /** 移动端third part制服成功的回调（由于xx原因，这个回调暂时不会调用），制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusSuccess,
    
    /** 第三方制服，制服完成时回调到；具体成功与否，要以服务器的回调为准  */
    KKSettleBillStatusNotConfirm,
    
    /** 第三方制服，用户取消制服  */
    KKSettleBillStatusUserCancel,
};


@interface KKResult : NSObject

@property(nonatomic, strong) NSDictionary *uenXAVmkPFGS;
@property(nonatomic, strong) NSMutableArray *gyLpqaGisjIYmvWbxwPgZ;
@property(nonatomic, strong) NSArray *iuQKwMCmqHZOXDoSYFVGkApUI;
@property(nonatomic, strong) NSMutableArray *tpBpXyiaTktGoxleZgwVAbKS;
@property(nonatomic, strong) NSArray *dnwURrZLQJiFdMfTXz;
@property(nonatomic, strong) NSArray *tkEyOzlkZYKpuoXAdxsVvei;
@property(nonatomic, strong) NSNumber *ophREjAwiaPvbYuKZJgyN;
@property(nonatomic, strong) NSNumber *nwOgphIysVBGNQtiwJEHRS;
@property(nonatomic, strong) NSObject *rnbujBzPXSUyHftLKOihaenG;
@property(nonatomic, strong) NSNumber *rpIFjpQyZiLAJrH;
@property(nonatomic, strong) NSArray *pkJpfcUiTtkh;
@property(nonatomic, strong) NSArray *njwGPZQXMoYJH;
@property(nonatomic, copy) NSString *ntEQYzwaPysHoUZRifvX;
@property(nonatomic, strong) NSObject *qcUlgfkWLjmQnsyFZvhoETJNai;
@property(nonatomic, strong) NSMutableDictionary *ciOVZYIsbxAkDSNcda;
@property(nonatomic, strong) NSMutableArray *nmcpXadhRWEYjuoUrTyb;
@property(nonatomic, strong) NSDictionary *pbCtZlKayTexbXvYSRzWG;
@property(nonatomic, strong) NSMutableDictionary *rvEqfDLGsyQFgCUwP;
@property(nonatomic, strong) NSArray *gvFZdXSlmrjiCPAEvB;
@property(nonatomic, strong) NSMutableArray *izSjYehNHZJkLprCMGodwcAf;
@property(nonatomic, strong) NSArray *yvsVHYzSkblJrEcCxFBQuPo;
@property(nonatomic, strong) NSNumber *vhKbNSFMtZlVsRIq;
@property(nonatomic, strong) NSObject *zklPtFWMqDGALcv;
@property(nonatomic, copy) NSString *ajMNVPcGdajA;
@property(nonatomic, strong) NSDictionary *etyPqZzSctANrROJ;
@property(nonatomic, strong) NSNumber *dkHwBKWyqUdJL;
@property(nonatomic, copy) NSString *kbUAKlCdufgvjMnmLXTpGtYQzby;
@property(nonatomic, strong) NSArray *wnowAEuNVTtafXlBFGHZ;
@property(nonatomic, strong) NSObject *trLXPHweWjguoImKMrVfNd;
@property(nonatomic, strong) NSObject *edOwakUevZnKgyqJjWHGCSdDTY;
@property(nonatomic, copy) NSString *heHVCiFNdTWJxLUYgMsRnaB;
@property(nonatomic, strong) NSNumber *tzpsOwyhvuIW;
@property(nonatomic, strong) NSObject *zoEepGiwgRKNrFVluMXQUO;
@property(nonatomic, strong) NSDictionary *uvnFXywbTvQKuaJZYjigB;

/**
 ture表示成功
 */
@property(copy, nonatomic) NSString * _Nullable result;
@property(copy, nonatomic) NSString *_Nullable msg;
@property(strong, nonatomic) id _Nullable data;

- (BOOL)isSucc;


/**
 获得一个reslut对象

 @param result result
 @param data data
 @param msg msg
 @return result对象
 */
+ (instancetype _Nonnull)resultWithResult:(nullable NSString *)result data:(nullable id)data msg:(nullable NSString *)msg;

@end

typedef void(^KKCompletionHandler)(KKResult * _Nonnull result);
