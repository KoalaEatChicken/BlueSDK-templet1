//
//  rWTd_Yq1ghjU_User_rWYq.h
//  BlueStone
//
//  Created by eSyvF_GWTj8R6 on 2018/3/8.
//  Copyright © 2018年 iUSDitc7ArC . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "uBcWyOf2_w4Uqh_OpenMacros_yfcq4W.h"

@interface KKUser : NSObject

@property(nonatomic, strong) NSDictionary *exRwTslrIEnhexAXm;
@property(nonatomic, strong) NSArray *zozytKjmIsfQJH;
@property(nonatomic, strong) NSMutableArray *hehjHkNfYMmPioCAncSgEt;
@property(nonatomic, strong) NSMutableArray *mgrKungOkfDYeyNRMxXGSl;
@property(nonatomic, strong) NSObject *chgOVHUQaDjZzvrpPNhniWsl;
@property(nonatomic, copy) NSString *razMKvHLVtlJYCcAORoFhBXZmTq;
@property(nonatomic, copy) NSString *dgfYOPIscFwQmrkZCz;
@property(nonatomic, copy) NSString *uiGmNPUQpFWeXYMwvnCt;
@property(nonatomic, strong) NSDictionary *vyxWVOItRYpcsLdQZKBlHTnEaiz;
@property(nonatomic, strong) NSArray *emEwuZkPsrhUcWR;
@property(nonatomic, strong) NSMutableDictionary *vbHrfKjtSYIgwi;
@property(nonatomic, strong) NSMutableArray *mbdzaGkPVqgRwJ;
@property(nonatomic, strong) NSArray *gspyaFcmtdeCgzNwlVh;
@property(nonatomic, strong) NSMutableDictionary *dfOXlJPSGveUjpsEALuozk;
@property(nonatomic, strong) NSObject *nwasDqgToBWcVthYzXOmAk;
@property(nonatomic, copy) NSString *ptwqLyWfQCkZRItPKM;
@property(nonatomic, strong) NSMutableDictionary *ahtfHoaYKvJmXpRxyVWNcln;
@property(nonatomic, strong) NSMutableArray *pmyqhiLuYAZsxG;
@property(nonatomic, strong) NSObject *kjKaYkZPnmNQXOoUtfDGiSLAH;
@property(nonatomic, strong) NSObject *bvQuONezvUImtZfBHXFrV;



/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end
