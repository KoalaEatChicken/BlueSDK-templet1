#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define KKRole YzYv_nFwibXjrTAtClWq
#define Koala fFKWwvoXDM1eQnlSHq
#define KKConfig R9rgCGUvb8z
#define KKResult TRmYhGaBXdbyco0
#define KKOrder ZiFGabhxr29vfNYRLu1Qz
#define KKUser gcbtadLONq2uPHkXFvh
#define kgk_postRoleInfoWithModel HsHY2AORJpMiwNmt4luE8
#define kgk_switchAccounts YQeFJTvZU1z2D7O
#define kgk_settleBillWithOrder v0Tp4hRBdbe
#define kgk_loginWithViewController Y5LGAcaC4PnkY
#define kgk_initGameKitWithCompletionHandler u_TAQ07Cck2LOFy3feZmX
#define kgk_openLog zAo5L96Jxpd72fSOc0aMi
#define kgk_demo_setPkver H65H3tBZizhbsq

#endif
