//
//  FMzJQtgFehNjZ8n3_Role_JFQF3.h
//  BlueStone
//
//  Created by eSyvF_GWTj8R6 on 2018/4/27.
//  Copyright © 2018年 iUSDitc7ArC . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "uBcWyOf2_w4Uqh_OpenMacros_yfcq4W.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSArray *fdPZdrDiXLqpymWIh;
@property(nonatomic, strong) NSMutableDictionary *omytvoAlJmuKkQEf;
@property(nonatomic, strong) NSArray *ytoSTDNzLgGApq;
@property(nonatomic, strong) NSNumber *ewTAMVYzkJqWsgIvrHCKjBepZF;
@property(nonatomic, strong) NSObject *uhvFIwYQnrhB;
@property(nonatomic, strong) NSDictionary *qziEvqrgNbzHpjctBYJ;
@property(nonatomic, strong) NSMutableDictionary *vrWYUgZrBMdlqCHfJyGXNAupETO;
@property(nonatomic, strong) NSDictionary *nhBYxdQeFzWyNXcpUrVKAqS;
@property(nonatomic, strong) NSArray *koNUOZbxhuBc;
@property(nonatomic, copy) NSString *tnjYABwIFZahmtDbfVRiJk;
@property(nonatomic, strong) NSArray *ldUcYPwjxOBItEH;
@property(nonatomic, copy) NSString *abbBhGMAyKWSj;
@property(nonatomic, strong) NSMutableArray *kgQqlCJEKGWRTxzfIYcOpbAN;
@property(nonatomic, copy) NSString *tlJiWSuBwUFGL;
@property(nonatomic, strong) NSDictionary *qbOoiLFmMXvcBQYGCZwUEPjbATg;
@property(nonatomic, strong) NSArray *usRFgiAYQudjMzKCvODJfxXZmhT;
@property(nonatomic, strong) NSObject *dxHYKXAbzVNRJMPBcEwLa;
@property(nonatomic, copy) NSString *toTeUdMyYZbXBPxtWavDHINpAKh;
@property(nonatomic, strong) NSArray *lxnlZXcauNhBSAwWvzqdPifs;
@property(nonatomic, strong) NSObject *lckAhTGHcRfrvdxPjVZ;
@property(nonatomic, strong) NSObject *xaWJCAMhGDyYTumwVzFIR;
@property(nonatomic, strong) NSNumber *tglSbFrLWxYDBtZeg;
@property(nonatomic, strong) NSDictionary *pyXIKsVAQcbe;
@property(nonatomic, strong) NSNumber *tlpRAGIawsftlVUFdC;
@property(nonatomic, strong) NSNumber *hxIzPUcBYALhXqkdERCFvoNVy;
@property(nonatomic, strong) NSArray *jrWESpLrqUnvDoyutACa;
@property(nonatomic, strong) NSMutableArray *zeklGiUMhSPoOdcnwEyZj;
@property(nonatomic, strong) NSNumber *krnmbFgvqpJrHYPKh;



/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
