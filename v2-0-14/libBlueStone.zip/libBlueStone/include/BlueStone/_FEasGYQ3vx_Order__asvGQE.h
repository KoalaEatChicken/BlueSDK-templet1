//
//  _FEasGYQ3vx_Order__asvGQE.h
//  BlueStone
//
//  Created by Tvf62Le0V4PT on 2018/3/5.
//  Copyright © 2018年 QB78HiQDNWP1 . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "ODi2OCbPcE6RKBag_OpenMacros_2gDPcbC.h"

@interface KKOrder : NSObject

@property(nonatomic, copy) NSString *lmArKXRezJE;
@property(nonatomic, strong) NSArray *beIUsXqzQhuSiF;
@property(nonatomic, strong) NSMutableDictionary *tculsxowMqVye;
@property(nonatomic, strong) NSMutableDictionary *jdteDJmCBfSOHsU;
@property(nonatomic, strong) NSMutableArray *psOZHbpaLwzxs;
@property(nonatomic, strong) NSMutableDictionary *gqCsceRDNra;
@property(nonatomic, strong) NSMutableArray *tsyvWOIaKDMw;
@property(nonatomic, strong) NSMutableArray *sdOilqajyZ;
@property(nonatomic, strong) NSMutableArray *rsyfeUgBdTVOHn;
@property(nonatomic, strong) NSDictionary *wiEUDnMAWZw;
@property(nonatomic, strong) NSDictionary *czwIDjkoBuz;
@property(nonatomic, strong) NSMutableDictionary *sxhDcZlnosu;
@property(nonatomic, strong) NSMutableDictionary *vkHDlMISQC;
@property(nonatomic, strong) NSMutableArray *yopmxPFbuL;




/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
