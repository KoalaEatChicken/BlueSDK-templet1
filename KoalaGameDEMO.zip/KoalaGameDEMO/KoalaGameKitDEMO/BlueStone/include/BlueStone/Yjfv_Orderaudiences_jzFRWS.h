// 订单
#import <Foundation/Foundation.h>
#import "FOOgxE_OpenMacrosfrontedge.h"
@interface KKOrder : NSObject
/** 商品名称  */
@property(nonatomic, copy) NSString *subject;
/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;
/** 订单号  */
@property(nonatomic, copy) NSString *billno;
/** 内购id  */
@property(nonatomic, copy) NSString *iapId;
/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;
/** 服务器id */
@property(nonatomic, copy) NSString *serverid;
/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;
/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
-(void)setSeparatedHMPvSw_bootstraptunermonophonicrename:(int)coderspinner_JdoQserrorseparated; 
-(void)setAccordingtoIPesotericsubjectoceanemittertruth_gallon:(int)azimuth_compasscarryaccordingto; 
-(void)setNonnumericVHpartycrazelegendfolder:(int)technology_compassindefinitelynonnumeric; 
-(void)setRotationMfallbackendedautomaticallyreproducer:(int)directorydel_extensionsletterrowunknownconsequently_MYjWsQrotation; 
@end
