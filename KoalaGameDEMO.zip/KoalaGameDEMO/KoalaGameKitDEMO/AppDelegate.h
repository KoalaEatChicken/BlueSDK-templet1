//
//  AppDelegate.h
//  KoalaGameKitDEMO
//
//  Created by kaola  on 2018/5/11.
//  Copyright © 2018年 kaola . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

