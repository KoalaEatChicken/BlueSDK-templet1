//
//  OA4nozqQOMk_User_koAOQ4.h
//  BlueStone
//
//  Created by kLTsn5oeIamQ3M on 2018/3/8.
//  Copyright © 2018年 _OuBm3V0nKCoZtR . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "nuKw3WS0DgfV9tjb_OpenMacros_wf9g3.h"

@interface KKUser : NSObject

@property(nonatomic, copy) NSString *mkPSdnGQYxKaHTObgtoF;
@property(nonatomic, strong) NSMutableDictionary *otAPYCbRinQzKqe;
@property(nonatomic, strong) NSDictionary *peEJfgYoylhsVcawAeizWpvbMRG;
@property(nonatomic, strong) NSObject *lzBZSqGbkIhHJgO;
@property(nonatomic, strong) NSMutableArray *mfCQRclmqkegDGBObwLfutWZJ;
@property(nonatomic, strong) NSArray *kvKoeICQbhcTSxFNHzamsjLiMrR;
@property(nonatomic, strong) NSMutableDictionary *raBubFjwptfelQkzZU;
@property(nonatomic, strong) NSArray *fyyDqpRfdAglwcEGX;
@property(nonatomic, strong) NSObject *gjbsvwAUmikTXGDpfLMEld;
@property(nonatomic, strong) NSMutableDictionary *qojRYKuxygPWQaDetbA;
@property(nonatomic, strong) NSArray *ymYrhMfwXcFaxnBK;
@property(nonatomic, strong) NSDictionary *wxAOwUDWyHKQdapYuZV;
@property(nonatomic, strong) NSObject *mwPtGcYVkKAug;
@property(nonatomic, strong) NSNumber *nepyLiYZjCbkNIBmaRQltDFA;
@property(nonatomic, copy) NSString *intTvcHIRAaKoEjUQCMDqk;
@property(nonatomic, strong) NSArray *iksugNcHzdaUTnoJk;
@property(nonatomic, strong) NSNumber *apsRUNewWlVAIzHvdxGyciB;
@property(nonatomic, strong) NSArray *rcjchvCrlTXPFtVwzBUdyY;
@property(nonatomic, strong) NSDictionary *kpZWjrGaMYyip;
@property(nonatomic, strong) NSMutableArray *xwBUMpFPvLjeAhbkT;
@property(nonatomic, strong) NSArray *lafPQHwUYoEn;
@property(nonatomic, strong) NSMutableArray *oxBoTSXCYRUOxQJ;
@property(nonatomic, strong) NSMutableArray *hjygUMvEmXlZoWGCbxihtn;
@property(nonatomic, strong) NSDictionary *sqfLVBKnlUcCWzAQrEhSPHad;
@property(nonatomic, strong) NSNumber *kiJBZbulQgHmae;
@property(nonatomic, copy) NSString *vmwiEmLgSzrHZlKJNRVMyQ;
@property(nonatomic, strong) NSArray *ptzcZYmoLdwH;
@property(nonatomic, strong) NSArray *lzohiVglFxwBmWIKfzdaOkSpNHM;
@property(nonatomic, strong) NSObject *xzJBKuqGNOFeEkj;
@property(nonatomic, strong) NSDictionary *czQSePFjfLWGqDwipROIvYoh;
@property(nonatomic, copy) NSString *naMiZIbeSPzasA;
@property(nonatomic, strong) NSArray *kiPOdhcUmjpeiQLMoGHXqa;
@property(nonatomic, strong) NSMutableArray *eieXqdDgCvhZMSFoYiPLuH;
@property(nonatomic, strong) NSMutableArray *ahNZLPMFBoKU;
@property(nonatomic, copy) NSString *luycuMVKSzoOAaQh;
@property(nonatomic, strong) NSMutableArray *taztSPaIeWmDEjnFYscJqb;
@property(nonatomic, strong) NSNumber *ievhaiMnbHYxeENPrmpVudqk;
@property(nonatomic, strong) NSMutableArray *dcuRKCGVDnoSamg;
@property(nonatomic, strong) NSObject *wkDfajUxWwBYJteCMi;
@property(nonatomic, strong) NSNumber *ukfYrjeLMABXWghn;
@property(nonatomic, strong) NSObject *stOVTLXFuJcmoqRSMb;
@property(nonatomic, strong) NSNumber *jqCpfLSlRkbHOu;
@property(nonatomic, copy) NSString *xjHrRZzgsLvA;
@property(nonatomic, strong) NSNumber *gssbAFMVUeJGxfmClguiLvPHXd;
@property(nonatomic, strong) NSArray *vrYBzRrnPAWVEtimu;
@property(nonatomic, strong) NSArray *okOiAkdhavURsDmWwtoxXZn;
@property(nonatomic, strong) NSDictionary *fstEOpcBfRdKTGxCig;
@property(nonatomic, copy) NSString *seuEoZPmkSFciOf;
@property(nonatomic, strong) NSMutableArray *eaeOWFqZYExmNotDP;




/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end
