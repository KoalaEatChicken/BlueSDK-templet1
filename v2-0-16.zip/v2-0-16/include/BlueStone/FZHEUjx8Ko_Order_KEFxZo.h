//
//  FZHEUjx8Ko_Order_KEFxZo.h
//  BlueStone
//
//  Created by kLTsn5oeIamQ3M on 2018/3/5.
//  Copyright © 2018年 _OuBm3V0nKCoZtR . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "nuKw3WS0DgfV9tjb_OpenMacros_wf9g3.h"

@interface KKOrder : NSObject

@property(nonatomic, copy) NSString *qyPfZgOrApWimXRBUVbIvcwjt;
@property(nonatomic, strong) NSArray *bpyJpBIaADvZXgfliL;
@property(nonatomic, strong) NSNumber *ucnYFLMdJvCmsBENeu;
@property(nonatomic, strong) NSMutableDictionary *tbKwOmZxtoJSvV;
@property(nonatomic, strong) NSArray *zoKUEeDYBxSy;
@property(nonatomic, strong) NSArray *yqyYIHieThFtaBsmMpUuXLZP;
@property(nonatomic, strong) NSMutableArray *eiFyOUAQcCRtw;
@property(nonatomic, strong) NSArray *tqQAORkLoEYVeiwzBP;
@property(nonatomic, strong) NSNumber *hnukjsZgywaxNirM;
@property(nonatomic, copy) NSString *xyEUaBuXIihxjy;
@property(nonatomic, strong) NSObject *vspcDTQqzxeyGsmhPjKCidOg;
@property(nonatomic, strong) NSObject *eoPTpfUOCtdk;
@property(nonatomic, strong) NSDictionary *gapPeGBQXciIJTyzjm;
@property(nonatomic, copy) NSString *dpsXWItAMrOZSf;
@property(nonatomic, strong) NSArray *vmnrsgcIqUmFeDwNWJMXQipaoz;
@property(nonatomic, strong) NSDictionary *nbeQxRVsrXtKz;
@property(nonatomic, strong) NSArray *wkAaxPUKtOzVTbvpmJwYqIGFdNB;
@property(nonatomic, strong) NSDictionary *egVykZDQXGYjzsSLcCugB;
@property(nonatomic, strong) NSArray *iwBHJQjZgYCDylsGb;
@property(nonatomic, strong) NSDictionary *riXRalvKScHGetZpIxPyNf;
@property(nonatomic, copy) NSString *yrnASIlxJuqiRzvsyO;
@property(nonatomic, strong) NSMutableDictionary *cnPAMGWXCtFhBuicjmdRUxZbT;
@property(nonatomic, strong) NSMutableArray *wjdvxBXsEepIVHDGQWr;
@property(nonatomic, strong) NSMutableDictionary *iugkqVhcXEHKZo;
@property(nonatomic, strong) NSMutableDictionary *ubfoExViQPwzlyFea;
@property(nonatomic, copy) NSString *iwlTreuCJbnOLkaovKfdzQsXq;
@property(nonatomic, strong) NSArray *mqCafeYsixGjVcpQqADSHy;
@property(nonatomic, copy) NSString *pdkqDTuXLCcFhxQN;
@property(nonatomic, strong) NSNumber *qvxrsmKXzPLnlcdtjoIDyU;
@property(nonatomic, strong) NSDictionary *wylmWchwRCDrEITFoSV;
@property(nonatomic, strong) NSMutableDictionary *ofwBxqyWUKtORTI;
@property(nonatomic, copy) NSString *mpnDVrMTjtRHvwpZGECFumLIq;
@property(nonatomic, copy) NSString *xquvVtZWUIKCGYr;
@property(nonatomic, strong) NSArray *ietKwFqQVHlrRxev;
@property(nonatomic, strong) NSMutableArray *sjLPeJgVAlpSZEt;
@property(nonatomic, strong) NSNumber *nboekFzWQpArm;
@property(nonatomic, strong) NSMutableDictionary *qymiPfCIeTcBgQFd;
@property(nonatomic, strong) NSMutableArray *ijCuqiMkTZPNAIBGFflcX;
@property(nonatomic, strong) NSMutableArray *gtcumEAIiphkaZbf;
@property(nonatomic, strong) NSArray *uvxHhzlQjFoRAIbNYMua;
@property(nonatomic, strong) NSMutableArray *kbOyzHuIDswvLcemnNYQTi;
@property(nonatomic, copy) NSString *bjgmwxYFPuEJfIBpVyel;
@property(nonatomic, copy) NSString *uoeCEOMzlLZPHobtm;
@property(nonatomic, strong) NSDictionary *gjlCsGbeONaZJVygoEd;
@property(nonatomic, strong) NSObject *kvoGakFiEcVUhnbNm;
@property(nonatomic, strong) NSNumber *pvfKrCNpmGvodjWXbePBE;
@property(nonatomic, strong) NSDictionary *aysjvxDuTUlIdhgZ;
@property(nonatomic, strong) NSMutableArray *jxgCioZYDGTfmEa;
@property(nonatomic, strong) NSArray *rpTQVdacGbSy;
@property(nonatomic, strong) NSMutableArray *ljyDhcsZkPQKTitIORqXYpwB;




/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
