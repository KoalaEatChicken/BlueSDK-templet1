//
//  oulUx0oOzq__Role_Uz_xoou.h
//  BlueStone
//
//  Created by kLTsn5oeIamQ3M on 2018/4/27.
//  Copyright © 2018年 _OuBm3V0nKCoZtR . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "nuKw3WS0DgfV9tjb_OpenMacros_wf9g3.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSDictionary *rsyDdGnLgufhao;
@property(nonatomic, copy) NSString *najmlcyMbaeCPZYNV;
@property(nonatomic, strong) NSNumber *nyBSvTcubYdaVRyWADqzQpKXUO;
@property(nonatomic, strong) NSMutableDictionary *shkHjGdWLNMYxSBAnCERcZmX;
@property(nonatomic, strong) NSMutableArray *cskOUIBlcLvpgMzfjeExDs;
@property(nonatomic, strong) NSMutableArray *hkgEahsYlVRDoMZumvdNKf;
@property(nonatomic, strong) NSMutableDictionary *wjapkORtmcbA;
@property(nonatomic, copy) NSString *xnKgTAXDherBqRlm;
@property(nonatomic, strong) NSDictionary *ogMdnomEgvuKhWD;
@property(nonatomic, strong) NSMutableArray *gnswlzUDfjOrYnumbkNCK;
@property(nonatomic, strong) NSObject *psrkbRLjNWpJTgcvXSuHfes;
@property(nonatomic, strong) NSMutableDictionary *swjwXQAESJfTxhGptr;
@property(nonatomic, strong) NSDictionary *ebaJlVInDBELFdzOgx;
@property(nonatomic, strong) NSMutableDictionary *zumpMxUYiAnzuGZfoFWKQVISk;
@property(nonatomic, strong) NSNumber *rcERUZHxnXvBksA;
@property(nonatomic, strong) NSArray *lvmTjkGtueYH;
@property(nonatomic, strong) NSArray *lkKRvFkwVQzfiyNMSmo;
@property(nonatomic, strong) NSMutableDictionary *aeGlhMONmExFAsytrUZowCv;
@property(nonatomic, strong) NSArray *epZYvGacMdUoJR;
@property(nonatomic, strong) NSObject *tnLxSqgZcEjrVTv;
@property(nonatomic, strong) NSMutableDictionary *hdqVpeljRvCoHdQgZinI;
@property(nonatomic, copy) NSString *adlgpAUDKJGPnBHqFwxvVuWS;
@property(nonatomic, strong) NSMutableDictionary *kgTMyoExsbrdugwJziaHfVpvjq;
@property(nonatomic, copy) NSString *wjAqocTBPWxYtaEKHkbuf;


/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
