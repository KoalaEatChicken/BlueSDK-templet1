#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define Koala L9NxIiSwlYAgHjpQsP7X
#define KKUser TM1ZDgFoKNnT
#define KKOrder aQbUnZtlI2PTKe
#define KKRole kcA0fjbEGY5dZxiNhs
#define KKResult g7RGh9O2AfX
#define KKConfig j3_f4TbKtkv025uh
#define kgk_loginWithViewController xOX8iEAw0ytsf
#define kgk_demo_setPkver U8sPqKaueQf_0OL
#define kgk_switchAccounts p961i7Hst5gNPEbho
#define kgk_postRoleInfoWithModel XZdAar_YwjsThn
#define kgk_initGameKitWithCompletionHandler j_L6AKBS7GdHwnUaDNXF
#define kgk_openLog Ggn9PLeRSOq_
#define kgk_settleBillWithOrder SKRJTBFk_bAg

#endif
