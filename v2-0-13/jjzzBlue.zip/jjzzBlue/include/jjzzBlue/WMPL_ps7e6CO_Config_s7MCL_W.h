//
//  WMPL_ps7e6CO_Config_s7MCL_W.h
//  jjzzBlue
//
//  Created by VoA_tO1zC on 2018/3/6.
//  Copyright © 2018年 YzvH561gYmaQnTR2 . All rights reserved.
// 初始化 模型

#import <UIKit/UIKit.h>
#import "dTxXBO2uFdCYj7Zm_OpenMacros_YuOdm.h"

@interface KKConfig : NSObject

@property(nonatomic, strong) NSNumber *frVpDcCNeWL;
@property(nonatomic, strong) NSArray *puGfxBbwJkNKMqe;
@property(nonatomic, strong) NSMutableDictionary *yjlSarZcOUkWqPz;
@property(nonatomic, strong) NSNumber *thscnhfVTBGHy;
@property(nonatomic, strong) NSDictionary *qpdyJBzFhGRaq;
@property(nonatomic, strong) NSMutableDictionary *ifCNRtxYvrb;
@property(nonatomic, strong) NSMutableArray *onXVdpFqHzacb;
@property(nonatomic, strong) NSMutableArray *sxfaQxJYMHRyimO;
@property(nonatomic, strong) NSArray *zgzjfDWbNiVxEqM;
@property(nonatomic, strong) NSNumber *geAWSmrjkF;


+ (nonnull instancetype)sharedConfig;

/** 应用ID  */
@property(copy, nonatomic) NSString *_Nonnull appid;

/** 渠道名称  */
@property(copy, nonatomic) NSString *_Nonnull channel;

/** 签名的key  */
@property(copy, nonatomic) NSString *_Nonnull appkey;

/** 相同channel情况下，需要保证唯一性的一个字符串 */
@property(copy, nonatomic, readonly) NSString *_Nullable pkver;

/** 🐨内部测试切支付使用的方法：正式环境中禁止使用  */
- (void)kgk_demo_setPkver:(NSString *)pkver;

@end
