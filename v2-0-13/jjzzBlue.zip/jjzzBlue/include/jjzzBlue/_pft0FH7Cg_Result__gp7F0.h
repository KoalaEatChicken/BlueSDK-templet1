//
//  _pft0FH7Cg_Result__gp7F0.h
//  jjzzBlue
//
//  Created by VoA_tO1zC on 2018/3/5.
//  Copyright © 2018年 YzvH561gYmaQnTR2 . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "dTxXBO2uFdCYj7Zm_OpenMacros_YuOdm.h"

/** 通知：登出成功 */
extern NSString * _Nonnull const KKNotiLogoutSuccessNoti;

/* 悬浮球的初始位置 */
typedef NS_ENUM(NSInteger, FloatBallStyle) {
    
    FloatBallStyleDefault,
    FloatBallStyleCenterLeft,
    FloatBallStyleCenterRight,
    FloatBallStyleTopLeft,
    FloatBallStyleTopRight,
    FloatBallStyleBottomLeft,
    FloatBallStyleBottomRight,
};

/* 制服结果的状态码 */
typedef NS_ENUM(NSInteger, KKSettleBillStatus) {
    
    /** 失败  */
    KKSettleBillStatusFailure,
    
    /** 移动端内购成功的回调，但是制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusIapSuccess,
    
    /** 移动端third part制服成功的回调（由于xx原因，这个回调暂时不会调用），制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusSuccess,
    
    /** 第三方制服，制服完成时回调到；具体成功与否，要以服务器的回调为准  */
    KKSettleBillStatusNotConfirm,
    
    /** 第三方制服，用户取消制服  */
    KKSettleBillStatusUserCancel,
};


@interface KKResult : NSObject

@property(nonatomic, strong) NSMutableArray *fzsZGRhBMfi;
@property(nonatomic, strong) NSArray *bvRAXxgUaP;
@property(nonatomic, copy) NSString *ipFXNYUaiEqr;
@property(nonatomic, strong) NSMutableDictionary *auinNGcyHu;
@property(nonatomic, strong) NSMutableArray *igJOAXYGwhL;
@property(nonatomic, strong) NSArray *peBzDbWOsvmZjXw;
@property(nonatomic, strong) NSDictionary *pbVOEeZsiPADk;
@property(nonatomic, copy) NSString *vclJmvozRDdH;
@property(nonatomic, strong) NSObject *thmWGXfBxzF;
@property(nonatomic, copy) NSString *witagQjZLNfOJc;
@property(nonatomic, strong) NSDictionary *hsHKFPuUfc;
@property(nonatomic, strong) NSMutableDictionary *gxnsrQZUkb;
@property(nonatomic, copy) NSString *yvMRsknoUmD;
@property(nonatomic, strong) NSArray *mweQIFgfKL;
@property(nonatomic, strong) NSArray *vcbevjSDOQ;
@property(nonatomic, copy) NSString *daaDmSoYuRlk;
@property(nonatomic, copy) NSString *qmiUPQsFaYVvn;
@property(nonatomic, strong) NSObject *halxELTqXYU;
@property(nonatomic, strong) NSMutableDictionary *ciExqAcYsSDeLvU;
@property(nonatomic, strong) NSNumber *hgcwgbYrTaxNov;
@property(nonatomic, strong) NSObject *wbUlWVhILuB;
@property(nonatomic, strong) NSMutableDictionary *edLVhDogXrBtP;
@property(nonatomic, strong) NSMutableDictionary *iaUYXcbhpSxwOIi;
@property(nonatomic, copy) NSString *ltrGBIlgtbAP;
@property(nonatomic, strong) NSArray *lwfQNXWnvPybzK;

/**
 ture表示成功
 */
@property(copy, nonatomic) NSString * _Nullable result;
@property(copy, nonatomic) NSString *_Nullable msg;
@property(strong, nonatomic) id _Nullable data;

- (BOOL)isSucc;


/**
 获得一个reslut对象

 @param result result
 @param data data
 @param msg msg
 @return result对象
 */
+ (instancetype _Nonnull)resultWithResult:(nullable NSString *)result data:(nullable id)data msg:(nullable NSString *)msg;

@end

typedef void(^KKCompletionHandler)(KKResult * _Nonnull result);
