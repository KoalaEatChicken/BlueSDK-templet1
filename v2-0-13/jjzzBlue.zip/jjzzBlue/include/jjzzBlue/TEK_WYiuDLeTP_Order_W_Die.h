//
//  TEK_WYiuDLeTP_Order_W_Die.h
//  jjzzBlue
//
//  Created by VoA_tO1zC on 2018/3/5.
//  Copyright © 2018年 YzvH561gYmaQnTR2 . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "dTxXBO2uFdCYj7Zm_OpenMacros_YuOdm.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSMutableDictionary *amPAFlvijOBC;
@property(nonatomic, copy) NSString *crVZoQMraiDk;
@property(nonatomic, strong) NSMutableDictionary *wcbpiFgDSBdj;
@property(nonatomic, strong) NSNumber *sowkyUYVaingXqP;
@property(nonatomic, strong) NSArray *hsbkgrLdmeP;
@property(nonatomic, copy) NSString *hvTmHXpVtl;
@property(nonatomic, strong) NSMutableDictionary *rtIlavJcOXxKj;
@property(nonatomic, copy) NSString *nwpZoEdsXKiCJ;
@property(nonatomic, strong) NSMutableDictionary *ayTlKadHyNwAve;
@property(nonatomic, strong) NSObject *nslqFUSAyXmELk;
@property(nonatomic, strong) NSArray *rgYvBRViTKD;
@property(nonatomic, copy) NSString *djGjAlOKHx;
@property(nonatomic, strong) NSDictionary *thlQmviRUNTAHM;
@property(nonatomic, strong) NSDictionary *vpkUThqiptMWjE;
@property(nonatomic, strong) NSArray *bonhldMTXCoZmO;
@property(nonatomic, copy) NSString *shLepoFHmNUMXI;
@property(nonatomic, strong) NSArray *aqOnpAUuYF;



/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
