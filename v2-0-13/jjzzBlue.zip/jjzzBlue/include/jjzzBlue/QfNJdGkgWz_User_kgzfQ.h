//
//  QfNJdGkgWz_User_kgzfQ.h
//  jjzzBlue
//
//  Created by VoA_tO1zC on 2018/3/8.
//  Copyright © 2018年 YzvH561gYmaQnTR2 . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "dTxXBO2uFdCYj7Zm_OpenMacros_YuOdm.h"

@interface KKUser : NSObject

@property(nonatomic, strong) NSDictionary *hyiSFsPdhcRpE;
@property(nonatomic, strong) NSArray *kygHYBNAPozEwQr;
@property(nonatomic, copy) NSString *fuiCecnMJklUaIj;
@property(nonatomic, strong) NSArray *rlutFTXYjabWl;
@property(nonatomic, strong) NSDictionary *iklfeMGdUoEVpQ;
@property(nonatomic, strong) NSObject *zfdhRjBMxJWopZH;
@property(nonatomic, strong) NSMutableArray *fkdwHZYDuyMpbKR;
@property(nonatomic, copy) NSString *evkEfDsuOYW;
@property(nonatomic, strong) NSArray *bpEwIPAZkWHsvTX;
@property(nonatomic, strong) NSDictionary *ujHlJyWPzuNjAb;
@property(nonatomic, strong) NSMutableDictionary *uaosDfMlPjT;
@property(nonatomic, strong) NSNumber *mzaGldCiODeAWhS;
@property(nonatomic, strong) NSArray *xdhTEWSBgCXv;
@property(nonatomic, strong) NSDictionary *rtYrmwALvPbs;
@property(nonatomic, copy) NSString *rxcgDCwfsrhd;
@property(nonatomic, strong) NSObject *qligjbNPxKcL;
@property(nonatomic, strong) NSMutableDictionary *vagmEKjIMCQZl;
@property(nonatomic, strong) NSNumber *fgAuYdHCGIvzjki;
@property(nonatomic, strong) NSMutableArray *szOeVuawAndP;
@property(nonatomic, copy) NSString *oaPixDrMUn;
@property(nonatomic, strong) NSMutableArray *qmGIakgHnCZNAoh;
@property(nonatomic, copy) NSString *aoIOVqjnDdyWPpE;
@property(nonatomic, strong) NSArray *qmHTBbWgmnD;
@property(nonatomic, strong) NSObject *hxcbUjZvMzEn;
@property(nonatomic, strong) NSArray *wsyuJxgNWKId;
@property(nonatomic, strong) NSDictionary *ykMkHgVUDqwGACe;
@property(nonatomic, copy) NSString *hvDcVBsmIvXMRSH;
@property(nonatomic, strong) NSMutableArray *adlicoBXYjMnGQI;
@property(nonatomic, strong) NSDictionary *ijlVsHCehY;


/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end
