#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define Koala F7t9wAkLx1z8
#define KKRole OeTbW5CMrVIUvp
#define KKConfig ZsYZpnivbeN6aQyRzW
#define KKOrder Lmu8AdWOfwTRDPB2
#define KKUser oQ8wiT_ozZ6SAfOc
#define KKResult MzULX7dWtCAQmVnvkNGF
#define kgk_postRoleInfoWithModel bsXlKAUDPGMv
#define kgk_switchAccounts Va7Q5nTRhoXCPVS
#define kgk_settleBillWithOrder CVF_9dhPXust
#define kgk_openLog zKmfQ9wizotDeI
#define kgk_loginWithViewController bbpHXEsWAVGTu2
#define kgk_initGameKitWithCompletionHandler Ds6tTw9Y3ZydX
#define kgk_demo_setPkver WPKVUx4MBHnkjAtrWw0

#endif
