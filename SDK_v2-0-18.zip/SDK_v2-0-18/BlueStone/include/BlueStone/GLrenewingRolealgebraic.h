//
//角色统计模型
#import <Foundation/Foundation.h>
#import "FOOgxE_OpenMacrosfrontedge.h"
@interface KKRole : NSObject
/** 区服id */
@property(nonatomic, copy) NSString *serverid;
/** 区服名称 */
@property(nonatomic, copy) NSString *servername;
/** 角色ID */
@property(nonatomic, copy) NSString *roleid;
/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;
/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
-(void)setStrengthpresentphysicallyhiragana_SGIxinputsexist:(int)YQinterioruRLSessionmonitoringreorderalternativetstrength; 
-(void)setMaintainablefailedheadingoverall_SGfncipher:(NSString *)mailingaddre_Robimplicationmaintainable; 
-(void)setCalculateintegratorunlink_QWSyGlabels:(int)identificationlistener_multiplierdiagonalscalculate; 
-(void)setAuthenticationsituation_classretainsstrikedisposition:(NSString *)artificial_qlgzsorterfinishingauthentication; 
-(void)setStructurereorder_GUMiGlightyearssensor:(int)safely_framesdispatcherdocumentdelistructure; 
-(void)setStationspeaker_attributesetup:(int)demodulatebirthdayscattering_oajuechargestation; 
@end
